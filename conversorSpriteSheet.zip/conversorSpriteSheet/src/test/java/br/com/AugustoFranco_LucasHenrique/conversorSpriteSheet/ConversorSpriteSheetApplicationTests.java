package br.com.AugustoFranco_LucasHenrique.conversorSpriteSheet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConversorSpriteSheetApplicationTests {

	@Test
	void contextLoads() {
	}

}
