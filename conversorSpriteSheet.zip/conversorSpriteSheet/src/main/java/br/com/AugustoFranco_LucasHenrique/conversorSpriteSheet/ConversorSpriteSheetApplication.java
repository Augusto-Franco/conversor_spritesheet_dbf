package br.com.AugustoFranco_LucasHenrique.conversorSpriteSheet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import br.com.AugustoFranco_LucasHenrique.conversorSpriteSheet.model.Usuario;

@SpringBootApplication
public class ConversorSpriteSheetApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConversorSpriteSheetApplication.class, args);
		Usuario u = new Usuario();
	}

}
