package br.com.AugustoFranco_LucasHenrique.conversorSpriteSheet.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "arquivos")
public class Arquivos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idArquivos;

    @Column(nullable = false)
    private String diretorio;

    @ManyToOne
    @JoinColumn(name = "idConversao", nullable = false, foreignKey = @ForeignKey(name = "fk_conversoes_idConversoes"))
    private Conversoes conversao;

    public Arquivos(String diretorio, Conversoes conversao) {
        this.diretorio = diretorio;
        this.conversao = conversao;
    }
}
