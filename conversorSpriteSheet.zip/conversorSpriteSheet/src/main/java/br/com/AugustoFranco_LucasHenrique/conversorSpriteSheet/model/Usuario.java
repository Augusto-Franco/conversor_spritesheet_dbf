package br.com.AugustoFranco_LucasHenrique.conversorSpriteSheet.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "usuario")
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idUsuario;

    @Column(nullable = false)
    private String email;
    private String senha;
    private int tipo;
    private String nome;

    @ManyToOne
    @JoinColumn(name = "idPlano", nullable = false, foreignKey = @ForeignKey(name = "fk_plano_idPlano"))
    private Plano plano;

    public Usuario(String email, String senha, int tipo, String nome, Plano plano) {
        this.email = email;
        this.senha = senha;
        this.tipo = tipo;
        this.nome = nome;
        this.plano = plano;
    }
}
